// JARVIS Dashboard Application
class JARVISDashboard {
    constructor() {
        this.isActive = true;
        this.performanceData = {
            cpu_usage: 53,
            gpu_usage: 52,
            system_temp: 54,
            gpu_frequency: 210,
            memory_usage: 72.3,
            ram_usage: 29
        };
        
        this.conversationHistory = [
            {
                type: "user",
                message: "Hello JARVIS, how are you today?",
                timestamp: "14:30:25"
            },
            {
                type: "assistant", 
                message: "Good afternoon! I'm operating at optimal performance. How may I assist you today?",
                timestamp: "14:30:27"
            },
            {
                type: "user",
                message: "What's the weather like today?",
                timestamp: "14:31:15"
            },
            {
                type: "assistant",
                message: "The current weather is partly cloudy with a temperature of 24°C. Would you like more detailed forecast information?",
                timestamp: "14:31:18"
            }
        ];
        
        this.recommendations = [
            "System performance optimal",
            "Voice recognition active",
            "Model response time: 1.2s",
            "Memory usage within normal range"
        ];
        
        this.startTime = Date.now();
        this.init();
    }
    
    init() {
        this.updateGauges();
        this.displayConversationHistory();
        this.displayRecommendations();
        this.setupEventListeners();
        this.startRealTimeUpdates();
        this.updateTime();
        this.updateButtonStates();
    }
    
    updateGauges() {
        // Round values to whole numbers for clean display
        const cpuValue = Math.round(this.performanceData.cpu_usage);
        const gpuValue = Math.round(this.performanceData.gpu_usage);
        const tempValue = Math.round(this.performanceData.system_temp);
        
        this.updateGauge('cpu-progress', 'cpu-value', cpuValue, '%');
        this.updateGauge('gpu-progress', 'gpu-value', gpuValue, '%');
        this.updateGauge('temp-progress', 'temp-value', tempValue, '°C');
        
        // Update GPU frequency
        document.getElementById('gpu-freq').textContent = `${Math.round(this.performanceData.gpu_frequency)} MHz`;
        
        // Update response time
        const responseTime = (Math.random() * 0.5 + 1.0).toFixed(1);
        document.getElementById('response-time').textContent = `${responseTime}s`;
    }
    
    updateGauge(progressId, valueId, value, unit) {
        const progressElement = document.getElementById(progressId);
        const valueElement = document.getElementById(valueId);
        
        if (progressElement && valueElement) {
            const circumference = 2 * Math.PI * 80; // radius is 80
            const offset = circumference - (value / 100) * circumference;
            
            progressElement.style.strokeDashoffset = offset;
            valueElement.textContent = `${value}${unit}`;
            
            // Color coding based on value
            if (value > 80) {
                progressElement.style.stroke = '#ff4444';
                progressElement.style.filter = 'drop-shadow(0 0 10px rgba(255, 68, 68, 0.5))';
            } else if (value > 60) {
                progressElement.style.stroke = '#ffaa00';
                progressElement.style.filter = 'drop-shadow(0 0 10px rgba(255, 170, 0, 0.5))';
            } else {
                progressElement.style.stroke = '#00ffff';
                progressElement.style.filter = 'drop-shadow(0 0 10px rgba(0, 255, 255, 0.5))';
            }
        }
    }
    
    displayConversationHistory() {
        const container = document.getElementById('conversation-history');
        container.innerHTML = '';
        
        this.conversationHistory.forEach(message => {
            const messageElement = document.createElement('div');
            messageElement.className = `conversation-message ${message.type}`;
            messageElement.innerHTML = `
                <div class="message-content">${message.message}</div>
                <div class="message-time">${message.timestamp}</div>
            `;
            container.appendChild(messageElement);
        });
        
        // Scroll to bottom
        container.scrollTop = container.scrollHeight;
    }
    
    displayRecommendations() {
        const container = document.getElementById('recommendations-list');
        container.innerHTML = '';
        
        this.recommendations.forEach(recommendation => {
            const recElement = document.createElement('div');
            recElement.className = 'recommendation-item';
            recElement.textContent = recommendation;
            container.appendChild(recElement);
        });
    }
    
    setupEventListeners() {
        // Start JARVIS button
        document.getElementById('start-jarvis').addEventListener('click', () => {
            this.startJARVIS();
        });
        
        // Stop JARVIS button
        document.getElementById('stop-jarvis').addEventListener('click', () => {
            this.stopJARVIS();
        });
        
        // Quick action buttons
        document.querySelectorAll('.action-item').forEach(item => {
            item.addEventListener('click', (e) => {
                const action = e.currentTarget.dataset.action;
                this.handleQuickAction(action);
            });
        });
        
        // Add hover effects to gauges
        document.querySelectorAll('.gauge-wrapper').forEach(wrapper => {
            wrapper.addEventListener('mouseenter', () => {
                wrapper.style.transform = 'scale(1.05)';
                wrapper.style.transition = 'transform 0.3s ease';
            });
            
            wrapper.addEventListener('mouseleave', () => {
                wrapper.style.transform = 'scale(1)';
            });
        });
    }
    
    startJARVIS() {
        this.isActive = true;
        this.updateSystemStatus();
        this.updateButtonStates();
        this.addConversationMessage('assistant', 'JARVIS system activated. All systems online.', this.getCurrentTime());
        
        // Add visual feedback
        this.showNotification('JARVIS Started', 'success');
    }
    
    stopJARVIS() {
        this.isActive = false;
        this.updateSystemStatus();
        this.updateButtonStates();
        this.addConversationMessage('assistant', 'JARVIS system shutting down. Goodbye.', this.getCurrentTime());
        
        // Add visual feedback
        this.showNotification('JARVIS Stopped', 'warning');
    }
    
    updateButtonStates() {
        const startBtn = document.getElementById('start-jarvis');
        const stopBtn = document.getElementById('stop-jarvis');
        
        if (this.isActive) {
            startBtn.disabled = true;
            startBtn.style.opacity = '0.5';
            startBtn.innerHTML = '<span class="btn-icon">▶</span>JARVIS ACTIVE';
            
            stopBtn.disabled = false;
            stopBtn.style.opacity = '1';
            stopBtn.innerHTML = '<span class="btn-icon">⏹</span>STOP JARVIS';
        } else {
            startBtn.disabled = false;
            startBtn.style.opacity = '1';
            startBtn.innerHTML = '<span class="btn-icon">▶</span>START JARVIS';
            
            stopBtn.disabled = true;
            stopBtn.style.opacity = '0.5';
            stopBtn.innerHTML = '<span class="btn-icon">⏹</span>JARVIS INACTIVE';
        }
    }
    
    updateSystemStatus() {
        const statusIndicator = document.querySelector('.status-indicator');
        const statusText = document.querySelector('.status-text');
        
        if (this.isActive) {
            statusIndicator.classList.add('active');
            statusText.textContent = 'ACTIVE';
            statusText.style.color = '#00ff00';
        } else {
            statusIndicator.classList.remove('active');
            statusText.textContent = 'INACTIVE';
            statusText.style.color = '#ff4444';
        }
    }
    
    handleQuickAction(action) {
        // Remove active class from all items
        document.querySelectorAll('.action-item').forEach(item => {
            item.classList.remove('active');
        });
        
        // Add active class to clicked item
        document.querySelector(`[data-action="${action}"]`).classList.add('active');
        
        // Handle different actions
        switch(action) {
            case 'voice':
                this.addConversationMessage('assistant', 'Voice commands activated. Listening...', this.getCurrentTime());
                break;
            case 'settings':
                this.addConversationMessage('assistant', 'Settings panel accessed.', this.getCurrentTime());
                break;
            case 'performance':
                this.addConversationMessage('assistant', 'Performance monitoring enabled.', this.getCurrentTime());
                break;
            case 'logs':
                this.addConversationMessage('assistant', 'System logs accessed.', this.getCurrentTime());
                break;
        }
    }
    
    addConversationMessage(type, message, timestamp) {
        this.conversationHistory.push({ type, message, timestamp });
        this.displayConversationHistory();
    }
    
    getCurrentTime() {
        const now = new Date();
        return now.toLocaleTimeString('en-US', { 
            hour12: false, 
            hour: '2-digit', 
            minute: '2-digit', 
            second: '2-digit' 
        });
    }
    
    updateTime() {
        const timeElement = document.getElementById('current-time');
        const uptimeElement = document.getElementById('uptime');
        
        setInterval(() => {
            timeElement.textContent = this.getCurrentTime();
            
            // Calculate uptime
            const elapsed = Date.now() - this.startTime;
            const hours = Math.floor(elapsed / (1000 * 60 * 60));
            const minutes = Math.floor((elapsed % (1000 * 60 * 60)) / (1000 * 60));
            uptimeElement.textContent = `${hours}h ${minutes}m`;
        }, 1000);
    }
    
    startRealTimeUpdates() {
        setInterval(() => {
            // Simulate realistic performance fluctuations with controlled randomness
            this.performanceData.cpu_usage = Math.max(20, Math.min(90, 
                this.performanceData.cpu_usage + (Math.random() - 0.5) * 8));
            this.performanceData.gpu_usage = Math.max(15, Math.min(85, 
                this.performanceData.gpu_usage + (Math.random() - 0.5) * 6));
            this.performanceData.system_temp = Math.max(35, Math.min(80, 
                this.performanceData.system_temp + (Math.random() - 0.5) * 4));
            this.performanceData.gpu_frequency = Math.max(100, Math.min(300, 
                this.performanceData.gpu_frequency + (Math.random() - 0.5) * 15));
            
            // Update memory usage bars with smaller fluctuations
            this.performanceData.memory_usage = Math.max(50, Math.min(95, 
                this.performanceData.memory_usage + (Math.random() - 0.5) * 2));
            this.performanceData.ram_usage = Math.max(20, Math.min(80, 
                this.performanceData.ram_usage + (Math.random() - 0.5) * 3));
            
            // Update display
            this.updateGauges();
            this.updateMonitoringBars();
            
            // Occasionally add system messages
            if (Math.random() < 0.015) { // 1.5% chance every update
                const systemMessages = [
                    'System optimization complete.',
                    'Performance monitoring updated.',
                    'All systems functioning normally.',
                    'Voice recognition recalibrated.',
                    'Model response optimized.'
                ];
                const randomMessage = systemMessages[Math.floor(Math.random() * systemMessages.length)];
                this.addConversationMessage('assistant', randomMessage, this.getCurrentTime());
            }
        }, 2000); // Update every 2 seconds
    }
    
    updateMonitoringBars() {
        const memoryBar = document.querySelector('.monitor-item:first-child .monitor-progress');
        const memoryValue = document.querySelector('.monitor-item:first-child .monitor-value');
        const ramBar = document.querySelector('.monitor-item:last-child .monitor-progress');
        const ramValue = document.querySelector('.monitor-item:last-child .monitor-value');
        
        if (memoryBar && memoryValue) {
            const memoryPercent = Math.round(this.performanceData.memory_usage * 10) / 10; // Round to 1 decimal place
            memoryBar.style.width = `${memoryPercent}%`;
            memoryValue.textContent = `${memoryPercent}%`;
        }
        
        if (ramBar && ramValue) {
            const ramPercent = Math.round(this.performanceData.ram_usage);
            ramBar.style.width = `${ramPercent}%`;
            ramValue.textContent = `${ramPercent}%`;
        }
    }
    
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 16px 24px;
            background: rgba(26, 26, 26, 0.95);
            border: 1px solid ${type === 'success' ? '#00ff00' : type === 'warning' ? '#ffaa00' : '#00ffff'};
            border-radius: 8px;
            color: white;
            font-weight: bold;
            z-index: 1000;
            box-shadow: 0 0 20px ${type === 'success' ? 'rgba(0, 255, 0, 0.3)' : type === 'warning' ? 'rgba(255, 170, 0, 0.3)' : 'rgba(0, 255, 255, 0.3)'};
            animation: slideIn 0.3s ease;
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => {
                if (document.body.contains(notification)) {
                    document.body.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }
}

// Add CSS for notifications
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateX(100%);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }
    
    @keyframes slideOut {
        from {
            opacity: 1;
            transform: translateX(0);
        }
        to {
            opacity: 0;
            transform: translateX(100%);
        }
    }
    
    .notification {
        backdrop-filter: blur(10px);
    }
`;
document.head.appendChild(style);

// Initialize the dashboard when the page loads
document.addEventListener('DOMContentLoaded', () => {
    new JARVISDashboard();
});

// Add some interactive effects
document.addEventListener('DOMContentLoaded', () => {
    // Add particle effect to background
    const createParticle = () => {
        const particle = document.createElement('div');
        particle.style.cssText = `
            position: fixed;
            width: 2px;
            height: 2px;
            background: rgba(0, 255, 255, 0.6);
            border-radius: 50%;
            pointer-events: none;
            z-index: -1;
            animation: float 10s linear infinite;
        `;
        
        particle.style.left = Math.random() * 100 + 'vw';
        particle.style.top = '100vh';
        
        document.body.appendChild(particle);
        
        setTimeout(() => {
            if (document.body.contains(particle)) {
                document.body.removeChild(particle);
            }
        }, 10000);
    };
    
    // Create particles periodically
    setInterval(createParticle, 2000);
    
    // Add float animation
    const floatStyle = document.createElement('style');
    floatStyle.textContent = `
        @keyframes float {
            0% {
                transform: translateY(0) translateX(0);
                opacity: 0;
            }
            10% {
                opacity: 1;
            }
            90% {
                opacity: 1;
            }
            100% {
                transform: translateY(-100vh) translateX(${Math.random() * 100 - 50}px);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(floatStyle);
});